# Fourier Neural Operator — Notes & Design Rationale

**Equation:** Viscous Burgers'  `u_t + u·u_x = ν·u_xx`  on x ∈ [-1,1], t ∈ [0,1]  
**ν:** `0.01/π ≈ 0.003183` (same as the PINN project)  
**Task:** Operator learning — map any initial condition u₀(x) to the full solution u(x,t)

---

## Core Trade-off: PINN vs FNO

### Physics-Informed Neural Network (PINN)

The PINN in `inverse_problem/` learns to approximate **one specific solution**
by minimising a combined loss of:
- PDE residual at collocation points (enforces the physics)
- Initial condition at t = 0
- Boundary conditions at x = ±1
- (Optionally) sparse sensor data for the inverse problem

**Strengths:**
- No labelled training data required — the physics is the supervision signal
- Enforces the governing equation structurally during training
- The solution it learns is physics-consistent (up to optimisation error)

**Critical limitation:**
- **Must be retrained from scratch for every new scenario** (new IC, new ν, new domain)
- Each retrain costs ~minutes of GPU time
- Does not generalise: a PINN trained on `-sin(πx)` gives nonsense on any other IC

---

### Fourier Neural Operator (FNO)

The FNO in this folder learns a **solution operator** — a mapping from the space of
initial conditions to the space of solution trajectories.  Once trained, it can
evaluate any new IC in milliseconds without retraining.

**How it works:**
1. **Lift** the 1-D initial condition signal into a high-dimensional feature space
2. Apply **four Fourier layers**: each layer operates globally in frequency space
   (capturing long-range interactions) and locally via a bypass convolution
3. **Project** down to the output: one predicted value per spatial location × time step

The Fourier layers are the key innovation: standard convolutions are local
(limited receptive field), but multiplication in Fourier space is equivalent to
a global convolution — the FNO can capture the full spatial structure of the PDE
at each layer with O(N log N) cost.

**Strengths:**
- **Single training run generalises** to the entire distribution of ICs
- Inference is extremely fast (milliseconds per instance post-training)
- Scales well: training cost is amortised over all future queries

**Limitations:**
- **Requires labelled training data** — ground-truth solutions must be computed
  upfront (we use the Crank-Nicolson FD solver, which takes ~0.5s/instance on CPU)
- **Purely data-driven**: the FNO does not know it is solving Burgers' equation;
  it will give plausible-looking but unphysical predictions for ICs or parameters
  far outside the training distribution
- **Fixed discretisation**: this implementation maps N_x=256 → (N_x=256, N_t=100);
  changing the grid resolution requires retraining (or architectural changes)
- Needs ~1000 training examples to learn the operator; with fewer samples,
  accuracy degrades quickly

---

## Experimental Setup

| Item | Value |
|------|-------|
| Training samples | 800 (from 1000 total) |
| Validation samples | 100 |
| Test samples | 100 |
| IC family | Random sums of sin(kπx), k=1…5, amplitudes ∈ (-1,1) |
| Ground truth | Crank-Nicolson FD (N_fd=512, N_t_fd=2000) |
| FNO modes | 16 |
| FNO width | 64 |
| FNO depth | 4 Fourier layers |
| FNO parameters | ~670 k |
| Training | Adam + cosine annealing, 300 epochs, batch 32 |
| PINN comparison | Retrained per test instance, Adam 2000 + L-BFGS 1500 epochs |

---

## Interpretation of Results

When reading `outputs/eval_fno_vs_pinn.json` or the summary table plot, keep in
mind:

1. **The accuracy comparison is not perfectly apples-to-apples.** The PINN is
   retrained on each test IC (fair — it sees the specific IC), while the FNO was
   trained on a different 800-sample training set.  However the FNO was never
   shown any test IC, so its accuracy on test cases is a genuine generalisation
   measure.

2. **The PINN uses physics; the FNO does not.**  If the test IC is within the
   training distribution, the FNO should be accurate.  If you query the FNO on
   an IC very unlike anything in training (e.g., a sharp discontinuity when
   training only on smooth sines), expect degraded accuracy.  The PINN, by
   contrast, enforces the PDE and will handle unusual ICs reasonably as long as
   it is retrained.

3. **Training time asymmetry.** The FNO training time is a one-time fixed cost.
   The PINN cost is per-instance.  The break-even point is roughly:

       FNO training time / PINN retrain time ≈ break-even number of queries

   If you only ever need to solve the equation for 3–5 ICs, the PINN is cheaper
   overall.  Beyond ~10–20 queries, the FNO amortises its upfront cost and
   becomes cheaper per query.

4. **Uncertainty.** Neither method in this implementation produces calibrated
   uncertainty estimates.  The inverse PINN ensemble provides ν uncertainty only,
   not solution-field uncertainty.  Adding uncertainty to the FNO (e.g., via
   ensembles or MC dropout) is a natural extension.

---

## File Map

| File | Role |
|------|------|
| `model.py` | FNO1d architecture (SpectralConv1d, FourierLayer, FNO1d) |
| `data_gen.py` | Generate 1000 IC/solution pairs; save to `outputs/dataset.npz` |
| `train.py` | Supervised training loop; save best checkpoint to `outputs/fno_best.pt` |
| `evaluate.py` | Evaluate FNO on test set; optionally retrain PINN for comparison |
| `requirements.txt` | Python dependencies |
| `outputs/` | All generated data and checkpoints (git-ignored) |

## How to Run (on Colab GPU)

```bash
cd neural_operator

# Step 1 — generate dataset (~8 min on CPU, faster on GPU-accelerated numpy)
python data_gen.py

# Step 2 — train FNO (~5-15 min on T4 for 300 epochs)
python train.py --epochs 300 --lr 1e-3

# Step 3 — evaluate (optionally skip PINN retraining to save time)
python evaluate.py --n_pinn_eval 3
# or faster, FNO-only:
python evaluate.py --skip_pinn
```
