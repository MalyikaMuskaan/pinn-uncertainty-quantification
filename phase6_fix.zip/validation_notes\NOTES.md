# Phase 6 — Validation: Failure Analysis & Ablation Study

**Scope:** `burgers_pinn/failure_analysis.py` and `burgers_pinn/ablation.py`
**Equation:** Viscous Burgers'  `u_t + u·u_x = ν·u_xx`  on x∈[-1,1], t∈[0,1]
**IC:** `u(x,0) = -sin(πx)`,  **BC:** `u(±1,t) = 0`

---

## Part A — Failure Case Analysis

### Setup

A viscosity sweep tests the vanilla PINN (4×50 tanh, 5,000 epochs, Adam +
ReduceLROnPlateau) at four values of ν:

| Index | ν | Ratio vs baseline | Shock sharpness |
|-------|---|---|---|
| 0 | 0.01/π ≈ 3.18×10⁻³ | 1× (baseline) | Smooth near-shock |
| 1 | 0.005/π ≈ 1.59×10⁻³ | 2× | Moderate sharpening |
| 2 | 0.002/π ≈ 6.37×10⁻⁴ | 5× | Sharp shock |
| 3 | 0.001/π ≈ 3.18×10⁻⁴ | 10× | Near-discontinuity |

Each case uses an independent fresh model with the same architecture and
training schedule; the only change is ν in the PDE residual.

### Why PINNs Fail at Small ν — Two Complementary Mechanisms

#### 1. Spectral Bias (F-Principle)

Fully-connected neural networks trained by gradient descent preferentially
learn low-frequency components of the target function first
(Rahaman et al., 2019; Xu et al., 2019 — the "Frequency Principle" or
"F-Principle").  For Burgers' equation, the physically relevant feature at
small ν is a near-discontinuity — a function that requires very high spatial
frequencies to represent.  The PINN's tanh-activated network is biased toward
smooth, band-limited approximations; capturing a shock of width O(ν) requires
high-frequency content that the network resists learning.

Concretely: as ν → 0, the shock half-width scales as ~ν/|u_x_max| ≈ ν·π.
At ν = 0.001/π the shock is approximately 10× sharper than at the baseline.
The PINN would need to represent spatial oscillations at frequency ~1/ν in
the shock region, far outside the "comfortable" band of the network at these
depths and widths.

#### 2. Gradient Stiffness and PDE Residual Scale

The PDE residual at a collocation point near the shock is:

```
R = u_t + u·u_x − ν·u_xx
```

Near the shock, `|u_xx|` scales as `1/ν²` (the second derivative of a layer
of thickness O(ν) with amplitude O(1)).  The term `ν·u_xx` therefore scales
as `1/ν`.  For the PINN's loss to drive `R → 0`, the network must balance a
term of size O(1/ν) — at ν = 0.001/π this is ~3,000× larger than at baseline.

This causes **gradient stiffness**: the PDE loss dominates at the shock,
producing extremely large gradients that destabilise the Adam optimiser and
cause oscillations rather than convergence.  Meanwhile, the IC and BC losses
(which are O(1)) are dwarfed and effectively ignored during the phases when
the shock region dominates.

#### 3. Collocation Point Starvation

With uniform random collocation sampling, the probability that a point lands
in the shock region of width O(ν) is proportional to ν.  At ν = 0.001/π
approximately 0.03% of the 10,000 collocation points per epoch are inside the
shock.  This is roughly 3 points — statistically insufficient to constrain
the residual in the most critical region of the domain.

*Remedies known in the literature (not implemented here):*
- Adaptive collocation: resample proportionally to the current residual magnitude
  (RAR — Residual-Adaptive Refinement, Lu et al. 2021)
- Causal weighting: upweight collocation points at early time to enforce temporal
  causality (Wang et al. 2022)
- Loss-balancing / self-adaptive weights (Jin et al. 2021, McClenny & Braga-Neto 2023)
- Fourier feature embeddings (Tancik et al. 2020) to overcome spectral bias

### Expected Results

| ν | Expected Rel-L2 | Qualitative description |
|---|---|---|
| 0.01/π | ~5–15% | Good; established working case |
| 0.005/π | ~15–30% | Moderate degradation |
| 0.002/π | ~30–60% | Visible shock smearing |
| 0.001/π | ~60–150% | PINN predicts a smooth near-zero field; shock entirely missed |

The heatmap comparison at ν = 0.001/π should show:
- **FD reference:** a sharp (visually thin) red→blue transition at x ≈ 0 for t > 0.5
- **PINN prediction:** a heavily smeared transition, possibly shifted in x
- **Error panel:** peak error concentrated in a vertical stripe at the shock location

### Output Files

| File | Description |
|------|-------------|
| `outputs/failure_analysis/model_nu_{0..3}.pt` | Trained checkpoints per ν |
| `outputs/failure_analysis/metrics.json` | Rel-L2 per ν |
| `outputs/failure_analysis/failure_error_vs_nu.png` | Log-log error vs ν with reference slope lines |
| `outputs/failure_analysis/failure_heatmap_comparison.png` | 3-panel comparison at worst ν |

---

## Part B — Ablation Study

### Ablation A — Ensemble Size

Tests M ∈ {3, 5, 10, 20} ensemble members at the baseline ν = 0.01/π.

**Key design decision:** Members 0–9 are reused directly from
`outputs/ensemble/model_{0..9}.pt` (already trained in sub-project 1).
M = 3 uses members {0,1,2}; M = 5 uses {0..4}; M = 10 reuses all 10.
M = 20 requires 10 additional members (seeds 10–19), trained on first run and
saved to `outputs/ablation/ensemble_size/member_{10..19}.pt`.

**Metrics:** ECE, empirical 90% coverage, MSE of ensemble mean vs FD reference.

**Expected findings:**

| M | Expected ECE | Expected 90% coverage | Notes |
|---|---|---|---|
| 3 | ~0.15–0.20 | ~0.70–0.80 | High variance; members too few for stable mean |
| 5 | ~0.10–0.15 | ~0.80–0.87 | Meaningful improvement |
| 10 | ~0.083 | ~0.886 | Baseline measured result |
| 20 | ~0.07–0.08 | ~0.89–0.92 | Diminishing returns expected |

The law of diminishing returns for ensemble UQ is well-established
(Lakshminarayanan et al. 2017): most of the calibration gain comes from
going from M=1 to M=5; beyond M=10 the improvement is marginal.

**Key conclusion:** The M=5 result (half the training cost of M=10) likely
retains ~90% of the calibration benefit — a practical recommendation for
compute-limited settings.

### Ablation B — Loss Weighting

Trains a single PINN three times at the baseline ν with:

| Scheme | λ_pde | λ_ic | λ_bc | Rationale |
|--------|-------|------|------|-----------|
| (a) Baseline | 1 | 10 | 10 | IC/BC need priority at early training |
| (b) Uniform | 1 | 1 | 1 | No a priori weighting |
| (c) Auto-balanced | 1 | computed | computed | Equal weighted contributions at epoch 0 |

For scheme (c), λ_ic and λ_bc are set so that
`λ_pde·L_pde0 = λ_ic·L_ic0 = λ_bc·L_bc0` at the initial (random) parameter
values.  This is the same strategy proven effective in the inverse problem
sub-project, where it reduced ν recovery error by 3–10×.

**Expected findings:**

The baseline (a) was manually tuned for this specific problem and should
perform best or comparably to auto-balanced.  Uniform (b) is expected to
be the worst: without upweighting IC/BC, the network can satisfy the PDE
residual in the interior while violating the boundary conditions, producing
a solution that satisfies the wrong problem.

The auto-balanced (c) scheme is problem-agnostic and should be competitive
with the baseline, offering a principled alternative that requires no manual
tuning.  This comparison directly motivates the design choice made in the
inverse problem sub-project.

**Key conclusion:** The relative ordering (a) ≈ (c) > (b) would confirm that:
1. IC/BC need non-trivial weighting (uniform is insufficient)
2. Auto-balancing is a practical substitute for manual weight tuning

### Output Files

| File | Description |
|------|-------------|
| `outputs/ablation/ensemble_size/ensemble_size_metrics.json` | ECE, coverage, MSE per M |
| `outputs/ablation/ensemble_size/ablation_ensemble_size.png` | ECE + 90% coverage vs M |
| `outputs/ablation/ensemble_size/member_{10..19}.pt` | Extra members for M=20 |
| `outputs/ablation/loss_weighting/loss_weighting_metrics.json` | MSE, Rel-L2 per scheme |
| `outputs/ablation/loss_weighting/ablation_loss_weighting.png` | Bar chart of MSE per scheme |
| `outputs/ablation/loss_weighting/model_scheme_{a,b,c}.pt` | Trained checkpoints |

---

## Summary — Which Design Choices Matter Most

### Failure analysis

The single most impactful factor in PINN accuracy for Burgers-type problems
is **ν** (equivalently, shock sharpness).  No architecture or training
hyperparameter change within the standard PINN framework fully overcomes
the spectral bias + gradient stiffness combination at ν ≤ 0.001/π.  The
path forward for sharp-shock problems requires structural changes: adaptive
collocation, causal training, or switching to operator learning (FNO, trained
in sub-project 4) which sidesteps the PDE residual stiffness entirely.

### Ablation B — Loss weighting matters more than ensemble size

The loss weighting ablation is expected to show a larger spread in final MSE
(possibly 2–5× between schemes) than the ensemble size ablation shows in ECE
at fixed M.  This makes loss weighting the **higher-leverage design choice**:
getting the weight balance right first, then scaling ensemble size, is the
recommended workflow.

### Cross-project connection

The auto-balance strategy (ablation B, scheme c) is the same mechanism
that reduced inverse problem error from 400–700% to 17–240%.  If ablation B
confirms it is competitive with the manually-tuned baseline on the forward
problem too, this provides strong evidence for using auto-balancing as the
default weighting strategy across all PINN problems in this project.

---

## How to Run (Colab GPU)

```bash
cd burgers_pinn

# Part A — Failure analysis (4 training runs × ~7 min each = ~28 min on T4)
python failure_analysis.py

# Part B — Ablation (10 new ensemble members + 3 PINN runs = ~1.5 hr on T4)
python ablation.py

# Run only one ablation:
python ablation.py --only ensemble
python ablation.py --only weighting
```

Checkpoints are skipped if they already exist, so runs can be safely
interrupted and resumed.
